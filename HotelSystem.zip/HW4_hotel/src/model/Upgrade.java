package model;

public interface Upgrade  {
	void upgrade();
}
