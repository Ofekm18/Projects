package utils;

public enum Area {
	
	Jerusalem ,Northern ,Haifa ,Central ,TelAviv ,Southern ,JudeaAndSamaria
}
 