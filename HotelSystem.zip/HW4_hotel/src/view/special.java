package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import model.Booking;
import model.Customer;
import model.Employee;
import model.Hotel;

public class special extends JInternalFrame  {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
    private Hotel hotel;

    

    public special() {
        setBounds(100, 100, 600, 600);

        contentPane = new JPanel(new GridLayout(10, 1, 0, 10));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        // Creating Hotel Instance
        this.hotel = Hotel.getInstance();


        // Creating Buttons
        JButton btnKEmployees = new JButton("Top K Employees");
        btnKEmployees.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                KEmployeesGui();
            }
        });
        styleButton(btnKEmployees);
        contentPane.add(btnKEmployees);

        JButton btnAllCustomersByPK = new JButton("All Customers By PK");
        btnAllCustomersByPK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                allCustomersByPKGui();
            }
        });
        styleButton(btnAllCustomersByPK);
        contentPane.add(btnAllCustomersByPK);

     // Creating the rest of the buttons

        JButton btnAllBookingsByRevenue = new JButton("All Bookings By Revenue");
        btnAllBookingsByRevenue.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                allBookingsByRevenueGui();
            }
        });
        styleButton(btnAllBookingsByRevenue);
        contentPane.add(btnAllBookingsByRevenue);

        JButton btnAllCustomersCmp = new JButton("All Customers By Comparison");
        btnAllCustomersCmp.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                allCustomersCmpGui();
            }
        });
        styleButton(btnAllCustomersCmp);
        contentPane.add(btnAllCustomersCmp);

        JButton btnTotalProfit = new JButton("Total Profit");
        btnTotalProfit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                totalProfitGui();
            }
        });
        styleButton(btnTotalProfit);
        contentPane.add(btnTotalProfit);

        JButton btnAllBookingsOfSpecCustomer = new JButton("All Bookings Of Specific Customer");
        btnAllBookingsOfSpecCustomer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                allBookingsOfSpecCustomerGui();
            }
        });
        styleButton(btnAllBookingsOfSpecCustomer);
        contentPane.add(btnAllBookingsOfSpecCustomer);

        JButton btnCustomerBookedTheMostRooms = new JButton("Customer Who Booked The Most Rooms");
        btnCustomerBookedTheMostRooms.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                customerBookedTheMostRoomsGui();
            }
        });
        styleButton(btnCustomerBookedTheMostRooms);
        contentPane.add(btnCustomerBookedTheMostRooms);

        JButton btnClose = new JButton("Close");
        btnClose.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        styleButton(btnClose);
        contentPane.add(btnClose);

    }

    // Styling method for buttons
    private void styleButton(JButton button) {
        button.setFont(new Font("Arial", Font.BOLD, 20));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(71, 62, 63));
    }
    private JTextField kField;

    private void KEmployeesGui() {
        // Clear all existing components on the panel
       
    	contentPane.removeAll();
        
        JButton btnSubmitKEmployees = new JButton("Show Top K Employees");

        kField = new JTextField();
        kField.setFont(new Font("Arial", Font.BOLD, 20));
        kField.setColumns(10); // adjust this value according to your needs

        styleButton(btnSubmitKEmployees);
        contentPane.add(btnSubmitKEmployees);
        contentPane.add(kField);
        kField.setFont(new Font("Arial", Font.BOLD, 20));
        // Create the text area for displaying customers and add it to a scroll pane
        JTextPane textPane = new JTextPane();
        textPane.setEditable(false); // Make it non-editable
        textPane.setBackground(new Color(210, 215, 211)); // Set background color
        textPane.setForeground(Color.BLACK); // Set text color

        // Center text
        StyledDocument doc = textPane.getStyledDocument();
        SimpleAttributeSet center = new SimpleAttributeSet();
        StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
        doc.setParagraphAttributes(0, doc.getLength(), center, false);

        JScrollPane scrollPane = new JScrollPane(textPane);
        scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT); // Align in the center
        contentPane.add(scrollPane);

        JButton btnClose = new JButton("Close");
        btnClose.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        styleButton(btnClose);
        contentPane.add(btnClose);

        // Add an ActionListener to the button to process the user input when button is clicked
        btnSubmitKEmployees.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                	
                    int k = Integer.parseInt(kField.getText());
                    List<Employee> kEmployees = hotel.KEmployees(k);

                    StringBuilder sb = new StringBuilder();
                    for(Employee emp : kEmployees) {
                        sb.append(emp.toString()).append("\n");
                    }

                    textPane.setText(sb.toString());

                } catch (NumberFormatException ex) {
                	System.out.println("dgs");
                    JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number for k.");
                } catch (Exception ex) {
                	System.out.println("dgs");
                    JOptionPane.showMessageDialog(null, "An error occurred while fetching data: " + ex.getMessage());
                }
            }
        });

        // Refresh the JFrame to show the new components
        this.revalidate();
        this.repaint();
    }


    private void allCustomersByPKGui() {
        try {
            // Create and configure the dialog
            JDialog dialog = new JDialog();
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            dialog.setSize(600, 400); // Set the size as you need
            dialog.setLocationRelativeTo(null); // To center the dialog

            // Create the input field for name filter
            JTextField nameFilterField = new JTextField(15);

            // Create the text area for displaying customers and add it to a scroll pane
            JTextArea textArea = new JTextArea(10, 30);
            textArea.setEditable(false); // Make it non-editable
            JScrollPane scrollPane = new JScrollPane(textArea);

            // Create the button for fetching and displaying customers
            JButton fetchButton = new JButton("Fetch Customers");
            fetchButton.addActionListener(e -> {
                ArrayList<Customer> result = hotel.allCustomersByPK();

                if (result != null && !result.isEmpty()) {
                    String nameFilter = nameFilterField.getText().trim();
                    StringBuilder message = new StringBuilder();

                    result.stream()  // convert list to stream
                        .filter(customer -> customer.getFirstName().toLowerCase().contains(nameFilter.toLowerCase())) // filter customers by name
                        .forEach(customer -> message.append(customer.getFirstName()).append("\n")); // append each customer's first name to the message

                    textArea.setText(message.toString());
                } else {
                    textArea.setText("No Customers found.");
                }
            });

            // Add everything to the dialog
            JPanel panel = new JPanel();
            panel.add(new JLabel("Enter a first name to filter:"));
            panel.add(nameFilterField);
            panel.add(fetchButton);
            panel.add(scrollPane);
            dialog.add(panel);

            dialog.setVisible(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


 // GUI command for allBookingsByRevenue
    private void allBookingsByRevenueGui() {
        try {
            TreeSet<Booking> result = hotel.allBookingByRevenue();

            // Create the text area for displaying bookings and add it to a scroll pane
            JTextPane textPane = new JTextPane();
            textPane.setEditable(false); // Make it non-editable
            textPane.setBackground(new Color(210, 215, 211)); // Set background color
            textPane.setForeground(Color.BLACK); // Set text color

            // Center text
            StyledDocument doc = textPane.getStyledDocument();
            SimpleAttributeSet center = new SimpleAttributeSet();
            StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
            doc.setParagraphAttributes(0, doc.getLength(), center, false);

            JScrollPane scrollPane = new JScrollPane(textPane);
            scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT); // Align in the center

            // Create a panel for the button and add it to the frame
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            panel.setBackground(Color.LIGHT_GRAY);

            // Create a label for instructions
            JLabel instructionLabel = new JLabel("Click the button below to fetch and display all hotel bookings sorted by revenue.");
            instructionLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Align in the center
            panel.add(instructionLabel);

            // Create a button for fetching data and add it to the panel
            JButton button = new JButton("Fetch Data");
            button.setAlignmentX(Component.CENTER_ALIGNMENT); // Align in the center
            panel.add(button);

            // Add an action listener to the button for fetching data and displaying it in the text area
            button.addActionListener(e -> {
                try {
                    StringBuilder message = new StringBuilder();
                    if (result != null && !result.isEmpty()) {
                        message.append("Bookings sorted by revenue:\n");
                        for (Booking booking : result) {
                            message.append("Booking Number: ").append(booking.getBookingNumber())
                                    .append(", Revenue: ").append(booking.getTotalRevenue()).append("\n");
                        }
                    } else {
                        message.append("No Bookings found.");
                    }
                    textPane.setText(message.toString());
                } catch (Exception ex) {
                    textPane.setText("An error occurred while fetching data: " + ex.getMessage());
                }
            });

            // Clear previous components and add new ones
            this.getContentPane().removeAll();
            this.getContentPane().add(panel, BorderLayout.NORTH);
            this.getContentPane().add(scrollPane, BorderLayout.CENTER);

            JButton btnClose = new JButton("Close");
            btnClose.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    setVisible(false);
                }
            });
            styleButton(btnClose);
            this.getContentPane().add(btnClose);

            // Revalidate and repaint to update GUI
            this.getContentPane().revalidate();
            this.getContentPane().repaint();

        } catch (Exception ex) {
            System.out.println("An error occurred while creating GUI: " + ex.getMessage());
        }
    }




    private void allCustomersCmpGui() {
        try {
            TreeSet<Customer> result = hotel.allCustomersCmp();

            // Create the text area for displaying customers and add it to a scroll pane
            JTextPane textPane = new JTextPane();
            textPane.setEditable(false); // Make it non-editable
            textPane.setBackground(new Color(210, 215, 211)); // Set background color
            textPane.setForeground(Color.BLACK); // Set text color

            // Center text
            StyledDocument doc = textPane.getStyledDocument();
            SimpleAttributeSet center = new SimpleAttributeSet();
            StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
            doc.setParagraphAttributes(0, doc.getLength(), center, false);

            JScrollPane scrollPane = new JScrollPane(textPane);
            scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT); // Align in the center

            // Create a panel for the button and add it to the frame
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            panel.setBackground(Color.LIGHT_GRAY);

            // Create a label for the instructions and add it to the panel
            JLabel instructions = new JLabel("Click the button below to display the customers sorted by bookings count.");
            instructions.setAlignmentX(Component.CENTER_ALIGNMENT); // Align in the center
            panel.add(instructions);

            // Create a button for fetching data and add it to the panel
            JButton button = new JButton("Fetch Data");
            button.setAlignmentX(Component.CENTER_ALIGNMENT); // Align in the center
            panel.add(button);

            // Add an action listener to the button for fetching data and displaying it in the text area
            button.addActionListener(e -> {
                StringBuilder message = new StringBuilder();
                if (result != null && !result.isEmpty()) {
                    message.append("Customers sorted by bookings count:\n");
                    for (Customer customer : result) {
                        message.append("Customer Name: ").append(customer.getFirstName()).append(" ")
                                .append(customer.getLastName()).append(", Bookings Count: ")
                                .append(customer.getAllBookings().size()).append("\n");
                    }
                } else {
                    message.append("No Customers found.");
                }
                textPane.setText(message.toString());
            });

            // Clear previous components and add new ones
            this.getContentPane().removeAll();
            this.getContentPane().add(panel, BorderLayout.NORTH);
            this.getContentPane().add(scrollPane, BorderLayout.CENTER);

            JButton btnClose = new JButton("Close");
            btnClose.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    setVisible(false);
                }
            });
            styleButton(btnClose);
            this.getContentPane().add(btnClose);

            // Revalidate and repaint to update GUI
            this.getContentPane().revalidate();
            this.getContentPane().repaint();

        } catch (Exception ex) {
            System.out.println("An error occurred while creating GUI: " + ex.getMessage());
        }
    }


 // GUI command for totalProfitGui
    private void totalProfitGui() {
        try {
            // Create the text area for displaying profit and add it to a scroll pane
            JTextPane textPane = new JTextPane();
            textPane.setEditable(false);
            textPane.setBackground(new Color(210, 215, 211));
            textPane.setForeground(Color.BLACK);

            // Center text
            StyledDocument doc = textPane.getStyledDocument();
            SimpleAttributeSet center = new SimpleAttributeSet();
            StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
            doc.setParagraphAttributes(0, doc.getLength(), center, false);

            JScrollPane scrollPane = new JScrollPane(textPane);
            scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT);

            // Create a panel for the button and add it to the frame
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            panel.setBackground(Color.LIGHT_GRAY);

            // Create a button for fetching data and add it to the panel
            JButton button = new JButton("Fetch Data");
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            panel.add(button);

            // Add an action listener to the button for fetching data and displaying it in the text area
            button.addActionListener(e -> {
                try {
                    int totalProfit = hotel.totalProfit();
                    textPane.setText("Total Profit: " + totalProfit);
                } catch (Exception ex) {
                    textPane.setText("An error occurred while calculating the total profit: " + ex.getMessage());
                }
            });

            // Add components to the frame
            this.getContentPane().removeAll();
            this.getContentPane().add(panel, BorderLayout.NORTH);
            this.getContentPane().add(scrollPane, BorderLayout.CENTER);

            JButton btnClose = new JButton("Close");
            btnClose.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    setVisible(false);
                }
            });
            styleButton(btnClose);
            this.getContentPane().add(btnClose);

            // Revalidate and repaint to update GUI
            this.getContentPane().revalidate();
            this.getContentPane().repaint();

        } catch (Exception ex) {
            System.out.println("An error occurred while creating GUI: " + ex.getMessage());
        }
    }

    private void allBookingsOfSpecCustomerGui() {
        // Create an input panel
        JPanel inputPanel = new JPanel(new FlowLayout());
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        inputPanel.setBackground(Color.LIGHT_GRAY);

        // Label, text field for customer ID, and a submit button
        JLabel customerIdLabel = new JLabel("Select the customer ID:");
        JComboBox<String> customersIDs = new JComboBox<String>();
    	Hotel hotelData = Hotel.getInstance();
        HashMap<String, Customer> hotelCustomers = hotelData.getAllCustomers();
        Iterator<Map.Entry<String, Customer> > new_Iterator = hotelCustomers.entrySet().iterator();
        while (new_Iterator.hasNext()) {
        	Map.Entry<String, Customer> entry = new_Iterator.next();
        	Customer customer = entry.getValue();
        	customersIDs.addItem(customer.getId());
        }
        JButton submitButton = new JButton("Submit");
        JLabel errorLabel = new JLabel(""); // For displaying errors
        errorLabel.setForeground(Color.RED);

        inputPanel.add(customerIdLabel);
        inputPanel.add(customersIDs);
        inputPanel.add(submitButton);

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String customerID = (String) customersIDs.getSelectedItem();

                    if ((customerID == null) || customerID.isEmpty()) {
                        errorLabel.setText("Customer ID cannot be empty!");
                        return;
                    }

                    List<Booking> result = hotel.allBookingsOfSpecCustomer(customerID);

                    // Create the text area for displaying bookings and add it to a scroll pane
                    JTextPane textPane = new JTextPane();
                    textPane.setEditable(false);
                    textPane.setBackground(new Color(210, 215, 211));
                    textPane.setForeground(Color.BLACK);

                    // Center text
                    StyledDocument doc = textPane.getStyledDocument();
                    SimpleAttributeSet center = new SimpleAttributeSet();
                    StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
                    doc.setParagraphAttributes(0, doc.getLength(), center, false);

                    JScrollPane scrollPane = new JScrollPane(textPane);
                    scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT);

                    // Message composition
                    StringBuilder message = new StringBuilder();
                    if (result != null && !result.isEmpty()) {
                        message.append("All Bookings of Customer ").append(customerID).append(":\n");
                        for (Booking booking : result) {
                            message.append("Booking Number: ").append(booking.getBookingNumber())
                                   .append(", Revenue: ").append(booking.getTotalRevenue()).append("\n");
                        }
                    } else {
                        message.append("No Bookings found for Customer ").append(customerID).append(".");
                    }
                    textPane.setText(message.toString());

                    // Replacing components
                    getContentPane().removeAll();
                    getContentPane().add(inputPanel, BorderLayout.NORTH);
                    getContentPane().add(scrollPane, BorderLayout.CENTER);
                    getContentPane().add(errorLabel, BorderLayout.SOUTH);

                    // Revalidate and repaint for visual updates
                    getContentPane().revalidate();
                    getContentPane().repaint();

                } catch (Exception ex) {
                    errorLabel.setText("An error occurred: " + ex.getMessage());
                }
            }
        });

        // Initial setup
        this.getContentPane().removeAll();
        this.getContentPane().add(inputPanel, BorderLayout.NORTH);
        this.getContentPane().add(errorLabel, BorderLayout.SOUTH);
        JButton btnClose = new JButton("Close");
        btnClose.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        styleButton(btnClose);
        this.getContentPane().add(btnClose);
        this.getContentPane().revalidate();
        this.getContentPane().repaint();
    }



    private void customerBookedTheMostRoomsGui() {
        try {
            Customer result = hotel.customerBookedTheMostRooms();

            // Create the text area for displaying the customer and add it to a scroll pane
            JTextPane textPane = new JTextPane();
            textPane.setEditable(false); 
            textPane.setBackground(new Color(210, 215, 211));
            textPane.setForeground(Color.BLACK);

            // Center text
            StyledDocument doc = textPane.getStyledDocument();
            SimpleAttributeSet center = new SimpleAttributeSet();
            StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
            doc.setParagraphAttributes(0, doc.getLength(), center, false);

            JScrollPane scrollPane = new JScrollPane(textPane);
            scrollPane.setAlignmentX(Component.CENTER_ALIGNMENT);

            // Create a panel for the display message
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            panel.setBackground(Color.LIGHT_GRAY);

            // Determine the message based on the result
            String message;
            if (result != null) {
                message = "Customer " + result.getFirstName() + " " + result.getLastName() + " booked the most rooms.";
            } else {
                message = "No Customers found.";
            }
            textPane.setText(message);

            // Clear previous components and add new ones
            this.getContentPane().removeAll();
            this.getContentPane().add(panel, BorderLayout.NORTH);
            this.getContentPane().add(scrollPane, BorderLayout.CENTER);

            JButton btnClose = new JButton("Close");
            btnClose.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    setVisible(false);
                }
            });
            styleButton(btnClose);
            this.getContentPane().add(btnClose);

            // Revalidate and repaint to update GUI
            this.getContentPane().revalidate();
            this.getContentPane().repaint();

        } catch (Exception ex) {
            System.out.println("An error occurred while creating GUI: " + ex.getMessage());
        }
    }


}