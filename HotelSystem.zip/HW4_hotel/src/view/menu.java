package view;

import java.awt.*;
import java.beans.PropertyVetoException;

import javax.swing.*;

import model.Hotel;

public class menu extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JDesktopPane desktopPane;
    private Hotel hotelData;
    private String userType;
    private AddRoom addRoomTypeGUI;
    AddRoom addRoomInternalFrame;
    private AddCustomerType customerTypeInternalFrame;
    private BookingGUI bookingInternalFrame;
    private AddDepartment addDepartmentInternalFrame;
    private AddEmployeeType employeeInternalFrame;
    private Remove removeScreen;
    private GetReal getRealGUI;
    private special specialInternalFrame;

    public menu(Hotel hotelData, String userType) {
        this.hotelData = hotelData;
        this.userType = userType;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        desktopPane = new JDesktopPane();

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        // File menu
        JMenu menuFile = new JMenu("File");
        menuBar.add(menuFile);
        JMenuItem itemSave = new JMenuItem("Save");
        menuFile.add(itemSave);
        itemSave.addActionListener(e -> save());
        JMenuItem itemExit = new JMenuItem("Exit");
        menuFile.add(itemExit);
        itemExit.addActionListener(e -> exit());

        // Add menu
        JMenu menuAdd = new JMenu("Add");
        menuBar.add(menuAdd);
        JMenuItem itemAddRoomType = new JMenuItem("Add Room Type");
        menuAdd.add(itemAddRoomType);
        itemAddRoomType.addActionListener(e -> openAddRoomType());
        JMenuItem itemAddCustomerType = new JMenuItem("Add Customer Type");
        menuAdd.add(itemAddCustomerType);
        itemAddCustomerType.addActionListener(e -> openCustomerTypeGUI());
        JMenuItem itemAddEmployeeType = new JMenuItem("Add Employee Type");
        menuAdd.add(itemAddEmployeeType);
        itemAddEmployeeType.setEnabled(userType.equals("Admin"));
        itemAddEmployeeType.addActionListener(e -> openEmployeeGUI());
        JMenuItem itemAddBooking = new JMenuItem("Add Booking");
        menuAdd.add(itemAddBooking);
        itemAddBooking.addActionListener(e -> openBookingGUI());
        JMenuItem itemAddDepartment = new JMenuItem("Add Department");
        menuAdd.add(itemAddDepartment);
        itemAddDepartment.addActionListener(e -> openAddDepartmentGUI());

        // Remove menu
        JMenu menuRemove = new JMenu("Remove");
        menuBar.add(menuRemove);
        JMenuItem itemRemove = new JMenuItem("Remove Screen");
        menuRemove.add(itemRemove);
        itemRemove.addActionListener(e -> openRemoveScreen(userType));

        // Check menu
        JMenu menuCheck = new JMenu("Check");
        menuBar.add(menuCheck);
        JMenuItem itemCheckExist = new JMenuItem("Check if Exist");
        menuCheck.add(itemCheckExist);
        itemCheckExist.addActionListener(e -> openGetRealGUI());

        // Special Actions menu
        JMenu menuSpecial = new JMenu("Special Actions");
        menuBar.add(menuSpecial);
        JMenuItem itemSpecialCommand = new JMenuItem("Special Command Screen");
        menuSpecial.add(itemSpecialCommand);
        itemSpecialCommand.addActionListener(e -> openSpecialCommandScreen());

        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon backgroundImage = new ImageIcon(getClass().getResource("/utils/3pR2.gif"));
                Image img = backgroundImage.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            }
        };
        contentPane.setLayout(new BorderLayout());

        JLabel hotelLabel = new JLabel("Welcome to Our Hotel Management System");
        hotelLabel.setFont(new Font("Arial", Font.BOLD, 30));
        hotelLabel.setForeground(Color.BLACK);
        hotelLabel.setOpaque(true);
        hotelLabel.setBackground(new Color(255, 255, 255, 100));
        hotelLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        contentPane.add(hotelLabel, BorderLayout.NORTH);

        setContentPane(contentPane);
        contentPane.add(desktopPane, BorderLayout.CENTER);
        desktopPane.setOpaque(false);
    }

   
    public void openCustomerTypeGUI() {
    	if (customerTypeInternalFrame != null)
            desktopPane.remove(customerTypeInternalFrame);
        customerTypeInternalFrame = new AddCustomerType(hotelData);
        desktopPane.add(customerTypeInternalFrame);
        customerTypeInternalFrame.setVisible(true); // Make the internal frame visible
    }

    public void openEmployeeGUI() {
    	if (employeeInternalFrame != null) {
    		employeeInternalFrame.setVisible(false);
            desktopPane.remove(employeeInternalFrame);
    	}

    	employeeInternalFrame = new AddEmployeeType(hotelData);
        desktopPane.add(employeeInternalFrame);
        employeeInternalFrame.setSize(1050, 450); // Set size as per your requirement
    	employeeInternalFrame.setVisible(true); // Make the internal frame visible
    }

    private void openGetRealGUI() {
    	if (getRealGUI != null) {
    		getRealGUI.setVisible(false);
    		desktopPane.remove(getRealGUI);
    	}
        getRealGUI = new GetReal();
        desktopPane.add(getRealGUI);
       	getRealGUI.setVisible(true);
    }


 // Update the openBookingGUI method to set the location of the BookingGUI frame
    public void openBookingGUI() {
    	if (bookingInternalFrame != null) {
    		bookingInternalFrame.setVisible(false);
            desktopPane.remove(bookingInternalFrame);
    	}
        bookingInternalFrame = new BookingGUI();
        bookingInternalFrame.setSize(650, 450);
        desktopPane.add(bookingInternalFrame);
    	bookingInternalFrame.setVisible(true); // Make the internal frame visible
    }


    // Add the "Add Room Type" functionality to the openAddRoomType method
    public void openAddRoomType() {
    	if (addRoomInternalFrame != null) {
    		addRoomInternalFrame.setVisible(false);
            desktopPane.remove(addRoomInternalFrame);
    	}

    	addRoomInternalFrame = new AddRoom(hotelData);
        addRoomInternalFrame.setSize(650, 450);
        desktopPane.add(addRoomInternalFrame);
    	addRoomInternalFrame.setVisible(true);
    }

    public void save() {
    	HotelAdapter.saveData(hotelData);
    }

    public void exit() {
    	System.exit(0);
    }

    private void openRemoveScreen(String userType) {
    	if (removeScreen != null)
    	{
    		removeScreen.setVisible(false);
    		desktopPane.remove(removeScreen);
    	}
        removeScreen = new Remove(userType);
        desktopPane.add(removeScreen);
       	removeScreen.setVisible(true);
    }

    private void openSpecialCommandScreen() {
    	if (specialInternalFrame != null) {
    		specialInternalFrame.setVisible(false);
    		desktopPane.remove(specialInternalFrame);
    	}
        specialInternalFrame = new special();
        specialInternalFrame.setVisible(true); // Make the internal frame visible
        desktopPane.add(specialInternalFrame);
        desktopPane.moveToFront(specialInternalFrame);
    }


    private void openAddDepartmentGUI() {
    	if (addDepartmentInternalFrame != null) {
    		addDepartmentInternalFrame.setVisible(false);
    		desktopPane.remove(addDepartmentInternalFrame);
    	}
        addDepartmentInternalFrame = new AddDepartment(hotelData);
        desktopPane.add(addDepartmentInternalFrame);
        addDepartmentInternalFrame.setVisible(true);
    }
}
