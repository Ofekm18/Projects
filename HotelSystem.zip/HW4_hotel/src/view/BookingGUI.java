package view;

import javax.swing.*;
import model.Booking;
import model.Customer;
import model.VIPCustomer;
import model.Hotel;
import model.Room;
import model.StandardRoom;
import utils.Area;
import utils.Gender;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class BookingGUI extends JInternalFrame {
    private static final long serialVersionUID = 1L;
    private JTextField checkInDateField, numberOfDaysField;
    private JComboBox<Customer> customers = new JComboBox<Customer>();
    private JComboBox<Room> rooms = new JComboBox<Room>();
    private JButton addButton, cancelButton;

    public BookingGUI() {
        setTitle("Add Booking");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);

        // Customer panel
        JPanel customerPanel = new JPanel();
        customerPanel.setLayout(new GridLayout(1, 2));

        customerPanel.add(new JLabel("Customer ID:"));
        customerPanel.add(customers);
    	Hotel hotelData = Hotel.getInstance();
        HashMap<String, Customer> hotelCustomers = hotelData.getAllCustomers();
        Iterator<Map.Entry<String, Customer> > new_Iterator = hotelCustomers.entrySet().iterator();
        while (new_Iterator.hasNext()) {
        	Map.Entry<String, Customer> entry = new_Iterator.next();
        	Customer customer = entry.getValue();
        	customers.addItem(customer);
        }
        HashMap<String, Room> hotelRooms = hotelData.getAllRooms();
        Iterator<Map.Entry<String, Room> > new_Iterator2 = hotelRooms.entrySet().iterator();
        while (new_Iterator2.hasNext()) {
        	Map.Entry<String, Room> entry = new_Iterator2.next();
        	Room room = entry.getValue();
        	rooms.addItem(room);
        }

        // Booking panel
        JPanel bookingPanel = new JPanel();
        bookingPanel.setLayout(new GridLayout(4, 2));
        checkInDateField = new JTextField();
        numberOfDaysField = new JTextField();
        addButton = new JButton("Add Booking");
        cancelButton = new JButton("Cancel");

        bookingPanel.add(new JLabel("Room Number:"));
        bookingPanel.add(rooms);
        bookingPanel.add(new JLabel("Check-in Date (dd/MM/yyyy):"));
        bookingPanel.add(checkInDateField);
        bookingPanel.add(new JLabel("Number of Days:"));
        bookingPanel.add(numberOfDaysField);
        bookingPanel.add(addButton);
        bookingPanel.add(cancelButton);

        // Main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.add(customerPanel, BorderLayout.NORTH);
        mainPanel.add(bookingPanel, BorderLayout.CENTER);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	Room room = (Room) rooms.getSelectedItem();
            	if (room == null) {
                    showErrorDialog("No selected room.");
                    return;
            	}
                String roomNumber = room.getRoomNumber();
                String checkInDateText = checkInDateField.getText();
                String numberOfDaysText = numberOfDaysField.getText();

                // Parse check-in date from string to Date object
                Date checkInDate = parseDate(checkInDateText);

                if (roomNumber.isEmpty() || checkInDate == null || !isValidIntInput(numberOfDaysText)) {
                    showErrorDialog("Please fill all fields with valid data.");
                    return;
                }

                int numberOfDays = Integer.parseInt(numberOfDaysText);

                Customer customer = (Customer) customers.getSelectedItem();
                if (customer == null) {
                    showErrorDialog("Customer not found. Please enter a valid customer ID.");
                    return;
                }

                Booking booking = new Booking(roomNumber, customer, checkInDate, numberOfDays);

                // Access the Hotel instance and add the booking
                Hotel hotel = Hotel.getInstance();
                if (hotel.addBooking(booking)) {
                    JOptionPane.showMessageDialog(null, "Booking added successfully");
                    setVisible(false);
                } else {
                    showErrorDialog("Booking already exists.");
                }
            }
        });

        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        setLayout(new BorderLayout());
        add(mainPanel, BorderLayout.CENTER);
    }

    private void showErrorDialog(String errorMessage) {
        Component parentComponent = this;
        JOptionPane.showMessageDialog(parentComponent, errorMessage, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private Date parseDate(String dateText) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            return dateFormat.parse(dateText);
        } catch (ParseException e) {
            showErrorDialog("Invalid date format. Please use 'dd/MM/yyyy'");
            return null;
        }
    }
 // check if valid
    private boolean isValidIntInput(String input) {
        try {
            Integer.parseInt(input);
            return true;
        } catch (NumberFormatException e) {
            showErrorDialog("Invalid integer input.");
            return false;
        }
    }

    
}
