package view;

import javax.swing.*;

import Exceptions.InvalidNumericStringException;
import model.Booking;
import model.Customer;
import model.Department;
import model.DepartmentManager;
import model.Employee;
import model.Hotel;
import model.PersonAlreadyExistException;
import model.Room;
import model.VIPCustomer;
import utils.Gender;
import utils.Area;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

public class AddCustomerType extends JInternalFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Hotel hotel;
    
    // For customer
    private JTextField customerIdField, customerFirstNameField, customerLastNameField, customerPhoneNumberField, customerYearOfBirthField;
    private JComboBox customerAreaBox, customerGenderBox;
    private JButton addCustomerButton;
    private JButton cancelButton;
    
    // For VIP customer
    private JTextField vipCustomerIdField, vipCustomerFirstNameField, vipCustomerLastNameField, vipCustomerPhoneNumberField, vipCustomerYearOfBirthField, vipCustomerDiscountPercentageField;
    private JComboBox vipCustomerAreaBox, vipCustomerGenderBox;
    private JButton addVipCustomerButton, cancelVipCustomerButton;

    public AddCustomerType(Hotel hotel) {
        this.hotel = hotel;
        setSize(800, 600);
        setTitle("Hotel Management System");

        // Create Tabbed Pane
        JTabbedPane tabbedPane = new JTabbedPane();

        // For Customer
        JPanel customerPanel = createCustomerPanel();
        tabbedPane.addTab("Add Customer", customerPanel);

        // For VIP Customer
        JPanel vipCustomerPanel = createVipCustomerPanel();
        tabbedPane.addTab("Add VIP Customer", vipCustomerPanel);

        // Add Tabbed Pane to frame
        add(tabbedPane);
    }

    private JPanel createCustomerPanel() {
        JPanel customerPanel = new JPanel();
        customerPanel.setLayout(new GridLayout(0, 2));

        customerIdField = new JTextField();
        customerFirstNameField = new JTextField();
        customerLastNameField = new JTextField();
        customerPhoneNumberField = new JTextField();
        customerYearOfBirthField = new JTextField();
        customerAreaBox = new JComboBox(Area.values());
        customerGenderBox = new JComboBox(Gender.values());
        
        customerPanel.add(new JLabel("ID:"));
        customerPanel.add(customerIdField);
        customerPanel.add(new JLabel("First Name:"));
        customerPanel.add(customerFirstNameField);
        customerPanel.add(new JLabel("Last Name:"));
        customerPanel.add(customerLastNameField);
        customerPanel.add(new JLabel("Phone Number:"));
        customerPanel.add(customerPhoneNumberField);
        customerPanel.add(new JLabel("Area:"));
        customerPanel.add(customerAreaBox);
        customerPanel.add(new JLabel("Gender:"));
        customerPanel.add(customerGenderBox);
        customerPanel.add(new JLabel("Year Of Birth:"));
        customerPanel.add(customerYearOfBirthField);

        addCustomerButton = new JButton("Add Customer");
        addCustomerButton.addActionListener(e -> {
            try {
                // Validate that all fields are not empty
                if (customerIdField.getText().isEmpty() ||
                    customerFirstNameField.getText().isEmpty() ||
                    customerLastNameField.getText().isEmpty() ||
                    customerPhoneNumberField.getText().isEmpty() ||
                    customerYearOfBirthField.getText().isEmpty()) {
                    throw new IllegalArgumentException("All fields must be filled");
                }

                // Validate that Year Of Birth field contain numerical values
                int yearOfBirth;
                try {
                    yearOfBirth = Integer.parseInt(customerYearOfBirthField.getText());
                } catch (NumberFormatException ex) {
                    throw new IllegalArgumentException("Year Of Birth field must contain numerical values");
                }
                try {
                    int id = Integer.parseInt(customerIdField.getText());
                } catch (NumberFormatException ex) {
                    throw new IllegalArgumentException("ID field must contain numerical values");
                }
                try {
                	Integer.parseInt(customerPhoneNumberField.getText());
                } catch(NumberFormatException nfe) {
                	throw new InvalidNumericStringException(nfe.getMessage());
                }

                if (hotel.getRealCustomer(customerIdField.getText()) != null) {
                    JOptionPane.showMessageDialog(this, "Customer with same ID already exist!!!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                Customer customer = new Customer(
                	    customerIdField.getText(),
                	    customerFirstNameField.getText(),
                	    customerLastNameField.getText(),
                	    customerPhoneNumberField.getText(),
                	    (Area) customerAreaBox.getSelectedItem(),
                	    (Gender) customerGenderBox.getSelectedItem(),
                	    yearOfBirth,
                	    new Date()  // Date of joining as current date
                	);

                if (hotel.addCustomer(customer)) {
	                JOptionPane.showMessageDialog(null, "Customer added successfully");
	                setVisible(false);
                }
                else {
	                JOptionPane.showMessageDialog(null, "Failed to add Customer");
                }
            } catch (PersonAlreadyExistException ex) {
                JOptionPane.showMessageDialog(null, "Error adding customer: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException ex) {
                // Show error message to the user
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } catch (InvalidNumericStringException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        customerPanel.add(addCustomerButton);
        cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				
			}
		});
        customerPanel.add(cancelButton);

        return customerPanel;
    }

    private JPanel createVipCustomerPanel() {
        JPanel vipCustomerPanel = new JPanel();
        vipCustomerPanel.setLayout(new GridLayout(0, 2));

        vipCustomerIdField = new JTextField();
        vipCustomerFirstNameField = new JTextField();
        vipCustomerLastNameField = new JTextField();
        vipCustomerPhoneNumberField = new JTextField();
        vipCustomerYearOfBirthField = new JTextField();
        vipCustomerDiscountPercentageField = new JTextField();
        vipCustomerAreaBox = new JComboBox(Area.values());
        vipCustomerGenderBox = new JComboBox(Gender.values());

        vipCustomerPanel.add(new JLabel("ID:"));
        vipCustomerPanel.add(vipCustomerIdField);
        vipCustomerPanel.add(new JLabel("First Name:"));
        vipCustomerPanel.add(vipCustomerFirstNameField);
        vipCustomerPanel.add(new JLabel("Last Name:"));
        vipCustomerPanel.add(vipCustomerLastNameField);
        vipCustomerPanel.add(new JLabel("Phone Number:"));
        vipCustomerPanel.add(vipCustomerPhoneNumberField);
        vipCustomerPanel.add(new JLabel("Area:"));
        vipCustomerPanel.add(vipCustomerAreaBox);
        vipCustomerPanel.add(new JLabel("Gender:"));
        vipCustomerPanel.add(vipCustomerGenderBox);
        vipCustomerPanel.add(new JLabel("Year Of Birth:"));
        vipCustomerPanel.add(vipCustomerYearOfBirthField);
        vipCustomerPanel.add(new JLabel("Discount Percentage:"));
        vipCustomerPanel.add(vipCustomerDiscountPercentageField);

        addVipCustomerButton = new JButton("Add VIP Customer");
        addVipCustomerButton.addActionListener(e -> {
            try {
                // Validate that all fields are not empty
                if (vipCustomerIdField.getText().isEmpty() ||
                    vipCustomerFirstNameField.getText().isEmpty() ||
                    vipCustomerLastNameField.getText().isEmpty() ||
                    vipCustomerPhoneNumberField.getText().isEmpty() ||
                    vipCustomerYearOfBirthField.getText().isEmpty() ||
                    vipCustomerDiscountPercentageField.getText().isEmpty()) {
                    throw new IllegalArgumentException("All fields must be filled");
                }

                // Validate that Year Of Birth and Discount Percentage fields contain numerical values
                int yearOfBirth;
                double discountPercentage;
                try {
                    yearOfBirth = Integer.parseInt(vipCustomerYearOfBirthField.getText());
                    discountPercentage = Double.parseDouble(vipCustomerDiscountPercentageField.getText());
                } catch (NumberFormatException ex) {
                    throw new IllegalArgumentException("Year Of Birth and Discount Percentage fields must contain numerical values");
                }
                if (hotel.getRealCustomer(vipCustomerIdField.getText()) != null) {
                    JOptionPane.showMessageDialog(this, "Customer with same ID already exist!!!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                VIPCustomer vipCustomer = new VIPCustomer(
                        vipCustomerIdField.getText(),
                        vipCustomerFirstNameField.getText(),
                        vipCustomerLastNameField.getText(),
                        vipCustomerPhoneNumberField.getText(),
                        (Area) vipCustomerAreaBox.getSelectedItem(),
                        (Gender) vipCustomerGenderBox.getSelectedItem(),
                        yearOfBirth,
                        new Date(),  // Date of joining as current date
                        discountPercentage
                );
                hotel.addVIPCustomer(vipCustomer);
                JOptionPane.showMessageDialog(null, "VIP Customer added successfully");
                setVisible(false);
            } catch (PersonAlreadyExistException ex) {
                JOptionPane.showMessageDialog(null, "Error adding VIP customer: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException ex) {
                // Show error message to the user
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        vipCustomerPanel.add(addVipCustomerButton);
        cancelVipCustomerButton = new JButton("Cancel");
        cancelVipCustomerButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				
			}
		});
        vipCustomerPanel.add(cancelVipCustomerButton);

        return vipCustomerPanel;
    
        
       
    }
        
     }