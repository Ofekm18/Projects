package view;

import javax.swing.*;
import model.Department;
import model.Hotel;
import utils.Specialization;

public class AddDepartment extends JInternalFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField departmentIdField;
    private JComboBox<Specialization> specializationComboBox;
    private Hotel hotelData;

    public AddDepartment(Hotel hotelData) {
        this.hotelData = hotelData;

        setTitle("Add Department");
        setSize(330, 200);
        setLayout(null);
        
        // Department ID Label and TextField
        JLabel departmentIdLabel = new JLabel("Department ID:");
        departmentIdLabel.setBounds(10, 20, 100, 25);
        add(departmentIdLabel);

        departmentIdField = new JTextField();
        departmentIdField.setBounds(120, 20, 150, 25);
        add(departmentIdField);
        
        // Specialization Label and ComboBox
        JLabel specializationLabel = new JLabel("Specialization:");
        specializationLabel.setBounds(10, 60, 100, 25);
        add(specializationLabel);
        
        specializationComboBox = new JComboBox<>(Specialization.values());
        specializationComboBox.setBounds(120, 60, 150, 25);
        add(specializationComboBox);
        
        // Add Department Button
        JButton addButton = new JButton("Add Department");
        addButton.setBounds(10, 110, 150, 30);
        addButton.addActionListener(e -> {
            addDepartment();
        });
        add(addButton);

        // Add Cancel Button
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBounds(180, 110, 120, 30);
        cancelButton.addActionListener(e -> {
            setVisible(false);
        });
        add(cancelButton);
    }
    
    private void addDepartment() {
        String departmentId = departmentIdField.getText().trim();
        if (departmentId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Department ID is empty!!!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (hotelData.getRealDepartment(departmentId) != null) {
            JOptionPane.showMessageDialog(this, "Department with same ID already exist!!!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        Specialization specialization = (Specialization) specializationComboBox.getSelectedItem();
        Department newDepartment = new Department(departmentId, specialization);
        
        // Using the addDepartment method of the Hotel class to add the new department
        if (hotelData.addDepartment(newDepartment)) {
            JOptionPane.showMessageDialog(this, "Department added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            setVisible(false);
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add department. It might already exist.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
   
}
