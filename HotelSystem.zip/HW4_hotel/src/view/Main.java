package view;

import model.Hotel;
import model.MaxPopulationCapacityException;
import model.StandardRoom;
public class Main {

    public static void main(String[] args) {
    	

        // Now, load the Hotel singleton data from the file
        Hotel hotel = HotelAdapter.loadData();
        if (hotel == null) {
            System.out.println("Failed to load hotel data. shutting down");
            return;
        }
        Login.run(args);
      
        // Save initial data to the file
        HotelAdapter.saveData(Hotel.getInstance());
    }
    public Hotel getHotel(Hotel hotel) {
    	return hotel;
    }
}
