package view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import model.Department;
import model.Employee;
import model.Hotel;

public class Login extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private JPasswordField passwordField;

    public static void run(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Login loginFrame = new Login();
                loginFrame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Login() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400);  // Increased size for a more spacious design
        contentPane = new JPanel();
        contentPane.setBackground(new Color(44, 62, 80));  // Dark blue background
        contentPane.setBorder(new EmptyBorder(30, 30, 30, 30));
        setContentPane(contentPane);
        contentPane.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.anchor = GridBagConstraints.NORTH;

        JLabel title = new JLabel("Hotel Management System Login");
        title.setForeground(Color.WHITE);  // White text color
        title.setFont(new Font("Arial", Font.BOLD, 28));
        contentPane.add(title, gbc);

        gbc.insets = new Insets(20, 0, 20, 0);  // Add some vertical spacing between components
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblNewLabel = new JLabel("ID");
        lblNewLabel.setForeground(Color.WHITE);  // White text color
        lblNewLabel.setFont(new Font("Arial", Font.BOLD, 20));
        textField = new JTextField(15);
        textField.setPreferredSize(new Dimension(200, 30));
        
        JLabel lblPassword = new JLabel("Password");
        lblPassword.setForeground(Color.WHITE);  // White text color
        lblPassword.setFont(new Font("Arial", Font.BOLD, 20));
        passwordField = new JPasswordField(15);
        passwordField.setPreferredSize(new Dimension(200, 30));

        JButton btnNewButton = new JButton("Login");
        btnNewButton.setBackground(new Color(34, 167, 240));  // Bright blue background
        btnNewButton.setForeground(Color.WHITE);  // White text color
        btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
        btnNewButton.setBorderPainted(false);
        btnNewButton.setFocusPainted(false);
        btnNewButton.setPreferredSize(new Dimension(200, 40));

        btnNewButton.addActionListener(e -> {
            String username = textField.getText();
            String password = new String(passwordField.getPassword());
            String userType = validateLoginCredentials(username, password);
            if (userType != null) {
                Hotel hotelData = Hotel.getInstance();
                if (hotelData == null) {
                    JOptionPane.showMessageDialog(Login.this, "Failed to load hotel data. Exiting.");
                    System.exit(0);
                }
                menu hotelGui = new menu(hotelData, userType);
                dispose();
                hotelGui.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(Login.this, "Invalid credentials. Please try again.");
            }
        });

        // Add components to the pane
        contentPane.add(lblNewLabel, gbc);
        contentPane.add(textField, gbc);
        contentPane.add(lblPassword, gbc);
        contentPane.add(passwordField, gbc);
        contentPane.add(btnNewButton, gbc);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                HotelAdapter.saveData(Hotel.getInstance());
                System.exit(0);
            }
        });
    }

    private String validateLoginCredentials(String username, String password) {
        if (username.equals("admin") && password.equals("admin")) {
            return "Admin";
        } else if (isValidEmployee(username, password)) {
            return "Employee";
        }
        return null;
    }
 // check if valid
    private boolean isValidEmployee(String username, String password) {
        Hotel hotelData = Hotel.getInstance();
        HashMap<String, Employee> hotelEmployees = hotelData.getAllEmployees();
        Iterator<Map.Entry<String, Employee> > new_Iterator = hotelEmployees.entrySet().iterator();
        while (new_Iterator.hasNext()) {
        	Map.Entry<String, Employee> entry = new_Iterator.next();
        	Employee employee = entry.getValue();
        	if (employee.getId().equals(username) && employee.getPassword().equals(password))
        		return true;
        }
        
        return false;
    }
}
