package view;

import javax.swing.*;


import model.Booking;
import model.Customer;
import model.Department;
import model.DepartmentManager;
import model.Employee;
import model.Hotel;
import model.Room;
import model.StandardRoom;
import model.Suite;
import model.SuperiorRoom;
import model.VIPCustomer;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyVetoException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Remove extends JInternalFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel resultLabel = new JLabel();
    private JComboBox<String> standardRooms = new JComboBox<String>();
    private JComboBox<String> superiorRooms = new JComboBox<String>();
    private JComboBox<String> suites = new JComboBox<String>();
    private JComboBox<String> employees = new JComboBox<String>();
    private JComboBox<String> departmentManagers = new JComboBox<String>();
    private JComboBox<String> departments = new JComboBox<String>();
    private JComboBox<String> bookings = new JComboBox<String>();
    private JComboBox<String> customers = new JComboBox<String>();
    private JComboBox<String> VIPCustomers = new JComboBox<String>();

    public Remove(String userType) {
        setTitle("Remove Screen");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new GridLayout(11, 2));

        createAndSetupButton("Remove Standard Room", e -> removeStandardRoomGui(), true);
        fillStandardRooms();
        add(standardRooms);
        createAndSetupButton("Remove Superior Room", e -> removeSuperiorRoomGui(), true);
        fillSuperiorRooms();
        add(superiorRooms);
        createAndSetupButton("Remove Suite", e -> removeSuiteGui(), true);
        fillSuites();
        add(suites);
        createAndSetupButton("Remove Employee", e -> removeEmployeeGui(), userType.equals("Admin"));
        fillEmployees();
        add(employees);
        createAndSetupButton("Remove Department Manager", e -> removeDepartmentManagerGui(), userType.equals("Admin"));
        fillDepartmentManagers();
        add(departmentManagers);
        createAndSetupButton("Remove Department", e -> removeDepartmentGui(), true);
        fillDepartments();
        add(departments);
        createAndSetupButton("Remove Booking", e -> removeBookingGui(), true);
        fillBookings();
        add(bookings);
        createAndSetupButton("Remove Customer", e -> removeCustomerGui(), true);
        fillCustomers();
        add(customers);
        createAndSetupButton("Remove VIP Customer", e -> removeVIPCustomerGui(), true);
        fillVIPCustomers();
        add(VIPCustomers);

        add(new JLabel("Result:"));
        add(resultLabel);
        createAndSetupButton("Close", e -> close(), true);

        try {
			setMaximum(true);
		} catch (PropertyVetoException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} // Maximize the internal frame
        pack(); // Adjust the size of the internal frame based on its contents
    }

    private void fillVIPCustomers() {
    	Hotel hotelData = Hotel.getInstance();
        HashMap<String, Customer> hotelCustomers = hotelData.getAllCustomers();
        Iterator<Map.Entry<String, Customer> > new_Iterator = hotelCustomers.entrySet().iterator();
        while (new_Iterator.hasNext()) {
        	Map.Entry<String, Customer> entry = new_Iterator.next();
        	Customer customer = entry.getValue();
        	if (customer instanceof VIPCustomer)
        		VIPCustomers.addItem(customer.getId());
        }
	}

	private void fillCustomers() {
    	Hotel hotelData = Hotel.getInstance();
        HashMap<String, Customer> hotelCustomers = hotelData.getAllCustomers();
        Iterator<Map.Entry<String, Customer> > new_Iterator = hotelCustomers.entrySet().iterator();
        while (new_Iterator.hasNext()) {
        	Map.Entry<String, Customer> entry = new_Iterator.next();
        	Customer customer = entry.getValue();
        	customers.addItem(customer.getId());
        }
	}

	private void fillBookings() {
    	Hotel hotelData = Hotel.getInstance();
        HashMap<String, Booking> hotelBookings = hotelData.getAllBookings();
        Iterator<Map.Entry<String, Booking> > new_Iterator = hotelBookings.entrySet().iterator();
        while (new_Iterator.hasNext()) {
        	Map.Entry<String, Booking> entry = new_Iterator.next();
        	Booking booking = entry.getValue();
        	bookings.addItem(booking.getBookingNumber());
        }
	}

	private void fillDepartments() {
    	Hotel hotelData = Hotel.getInstance();
        HashMap<String, Department> hotelDepartments = hotelData.getAllDepartments();
        Iterator<Map.Entry<String, Department> > new_Iterator = hotelDepartments.entrySet().iterator();
        while (new_Iterator.hasNext()) {
        	Map.Entry<String, Department> entry = new_Iterator.next();
        	Department department = entry.getValue();
        	departments.addItem(department.getDepartmentId());
        }
	}

	private void fillDepartmentManagers() {
    	Hotel hotelData = Hotel.getInstance();
        HashMap<String, Employee> hotelEmployees = hotelData.getAllEmployees();
        Iterator<Map.Entry<String, Employee> > new_Iterator = hotelEmployees.entrySet().iterator();
        while (new_Iterator.hasNext()) {
        	Map.Entry<String, Employee> entry = new_Iterator.next();
        	Employee employee = entry.getValue();
        	if (employee instanceof DepartmentManager)
        		departmentManagers.addItem(employee.getId());
        }
	}

	private void fillEmployees() {
    	Hotel hotelData = Hotel.getInstance();
        HashMap<String, Employee> hotelEmployees = hotelData.getAllEmployees();
        Iterator<Map.Entry<String, Employee> > new_Iterator = hotelEmployees.entrySet().iterator();
        while (new_Iterator.hasNext()) {
        	Map.Entry<String, Employee> entry = new_Iterator.next();
        	Employee employee = entry.getValue();
       		employees.addItem(employee.getId());
        }
	}

	private void fillSuites() {
    	Hotel hotelData = Hotel.getInstance();
        HashMap<String, Room> hotelRooms = hotelData.getAllRooms();
        Iterator<Map.Entry<String, Room> > new_Iterator = hotelRooms.entrySet().iterator();
        while (new_Iterator.hasNext()) {
        	Map.Entry<String, Room> entry = new_Iterator.next();
        	Room room = entry.getValue();
        	if (room instanceof Suite)
        		suites.addItem(room.getRoomNumber());
        }
	}

	private void fillSuperiorRooms() {
    	Hotel hotelData = Hotel.getInstance();
        HashMap<String, Room> hotelRooms = hotelData.getAllRooms();
        Iterator<Map.Entry<String, Room> > new_Iterator = hotelRooms.entrySet().iterator();
        while (new_Iterator.hasNext()) {
        	Map.Entry<String, Room> entry = new_Iterator.next();
        	Room room = entry.getValue();
        	if (room instanceof SuperiorRoom)
        		superiorRooms.addItem(room.getRoomNumber());
        }
	}

	private void fillStandardRooms() {
    	Hotel hotelData = Hotel.getInstance();
        HashMap<String, Room> hotelRooms = hotelData.getAllRooms();
        Iterator<Map.Entry<String, Room> > new_Iterator = hotelRooms.entrySet().iterator();
        while (new_Iterator.hasNext()) {
        	Map.Entry<String, Room> entry = new_Iterator.next();
        	Room room = entry.getValue();
        	if (room instanceof StandardRoom)
        		standardRooms.addItem(room.getRoomNumber());
        }
	}

	private void createAndSetupButton(String label, ActionListener action, boolean enabled) {
        JButton button = new JButton(label);
        button.addActionListener(action);
        add(button);
        button.setEnabled(enabled);
    
	}
          private void removeSuperiorRoomGui() {
              try {
                  SuperiorRoom superiorRoom = (SuperiorRoom) Hotel.getInstance().getRealSuperiorRoom((String)superiorRooms.getSelectedItem());
                  if (superiorRoom != null) {
                      boolean removed = Hotel.getInstance().removeSuperiorRoom(superiorRoom);
                      if (removed) {
                          JOptionPane.showMessageDialog(null, "Superior Room removed successfully!");
                          setVisible(false);
                      } else {
                          resultLabel.setText("Failed to remove Superior Room. Room not found.");
                      }
                  } else {
                      resultLabel.setText("Not selected a Superior Room.");
                  }
              } catch (Exception ex) {
                  resultLabel.setText("An error occurred while removing the Superior Room: " + ex.getMessage());
              }
          }
       // ... other class methods

          private void removeSuiteGui() {
              try {
                  Suite suite = (Suite) Hotel.getInstance().getRealSuite((String)suites.getSelectedItem());
                  if (suite != null) {
                      boolean removed = Hotel.getInstance().removeSuite(suite);
                      if (removed) {
                          JOptionPane.showMessageDialog(null, "Suite removed successfully!");
                          setVisible(false);
                      } else {
                          resultLabel.setText("Failed to remove Suite. Room not found.");
                      }
                  } else {
                      resultLabel.setText("Not selected a Suite.");
                  }
              } catch (Exception ex) {
                  resultLabel.setText("An error occurred while removing the Suite: " + ex.getMessage());
              }
          }

          private void removeEmployeeGui() {
              try {
                  Employee employee = (Employee) Hotel.getInstance().getRealEmployee((String)employees.getSelectedItem());
                  if (employee != null) {
                      boolean removed = Hotel.getInstance().removeEmployee(employee);
                      if (removed) {
                          JOptionPane.showMessageDialog(null, "Employee removed successfully!");
                          setVisible(false);
                      } else {
                          resultLabel.setText("Failed to remove Employee. Employee not found.");
                      }
                  } else {
                      resultLabel.setText("Not selected Employee.");
                  }
              } catch (Exception ex) {
                  resultLabel.setText("An error occurred while removing the Employee: " + ex.getMessage());
              }
          }

          private void removeDepartmentManagerGui() {
              try {
                  DepartmentManager manager = (DepartmentManager) Hotel.getInstance().getRealDepartmentManager((String)departmentManagers.getSelectedItem());
                  if (manager != null) {
                      boolean removed = Hotel.getInstance().removeDepartmentManager(manager);
                      if (removed) {
                          JOptionPane.showMessageDialog(null, "Department Manager removed successfully!");
                          setVisible(false);
                      } else {
                          resultLabel.setText("Failed to remove Department Manager. Manager not found.");
                      }
                  } else {
                      resultLabel.setText("Not selected Department Manager.");
                  }
              } catch (Exception ex) {
                  resultLabel.setText("An error occurred while removing the Department Manager: " + ex.getMessage());
              }
          }

          private void removeDepartmentGui() {
              try {
                  Department department = (Department) Hotel.getInstance().getRealDepartment((String)departments.getSelectedItem());
                  if (department != null) {
                      boolean removed = Hotel.getInstance().removeDepartment(department);
                      if (removed) {
                          JOptionPane.showMessageDialog(null, "Department removed successfully!");
                          setVisible(false);
                      } else {
                          resultLabel.setText("Failed to remove Department. Department not found.");
                      }
                  } else {
                      resultLabel.setText("Not selected a Department.");
                  }
              } catch (Exception ex) {
                  resultLabel.setText("An error occurred while removing the Department: " + ex.getMessage());
              }
          }

          private void removeBookingGui() {
              try {
                  Booking booking = (Booking) Hotel.getInstance().getRealBooking((String)bookings.getSelectedItem());
                  if (booking != null) {
                      boolean removed = Hotel.getInstance().removeBooking(booking);
                      if (removed) {
                          JOptionPane.showMessageDialog(null, "Booking removed successfully!");
                          setVisible(false);
                      } else {
                          resultLabel.setText("Failed to remove Booking. Booking not found.");
                      }
                  } else {
                      resultLabel.setText("Not selected Booking.");
                  }
              } catch (Exception ex) {
                  resultLabel.setText("An error occurred while removing the Booking: " + ex.getMessage());
              }
          }

          private void removeCustomerGui() {
              try {
                  Customer customer = (Customer) Hotel.getInstance().getRealCustomer((String)customers.getSelectedItem());
                  if (customer != null) {
                      boolean removed = Hotel.getInstance().removeCustomer(customer);
                      if (removed) {
                          JOptionPane.showMessageDialog(null, "Customer removed successfully!");
                          setVisible(false);
                      } else {
                          resultLabel.setText("Failed to remove Customer. Customer not found.");
                      }
                  } else {
                      resultLabel.setText("Not selected Customer");
                  }
              } catch (Exception ex) {
                  resultLabel.setText("An error occurred while removing the Customer: " + ex.getMessage());
              }
          }

          private void close() {
        	  setVisible(false);
          }
          private void removeVIPCustomerGui() {
              try {
                  VIPCustomer vipCustomer = (VIPCustomer) Hotel.getInstance().getRealVIPCustomer((String)VIPCustomers.getSelectedItem());
                  if (vipCustomer != null) {
                      boolean removed =  Hotel.getInstance().removeVIPCustomer(vipCustomer);
                      if (removed) {
                          JOptionPane.showMessageDialog(null, "VIP Customer removed successfully!");
                          setVisible(false);
                      } else {
                          resultLabel.setText("Failed to remove VIP Customer. VIP Customer not found.");
                      }
                  } else {
                      resultLabel.setText("Not selected VIP Customer");
                  }
              } catch (Exception ex) {
                  resultLabel.setText("An error occurred while removing the VIP Customer: " + ex.getMessage());
              }
          }

          private void removeStandardRoomGui() {
              try {
            	  StandardRoom room = (StandardRoom) Hotel.getInstance().getRealStandardRoom((String)standardRooms.getSelectedItem());
                  if (room != null) {
                      boolean removed = Hotel.getInstance().removeStandardRoom(room);
                      if (removed) {
                          JOptionPane.showMessageDialog(null, "Standard Room removed successfully!");
                          setVisible(false);
                      } else {
                          resultLabel.setText("Failed to remove Standard Room. Room not found.");
                      }
                  } else {
                      resultLabel.setText("Not selected a Standard Room.");
                  }
              } catch (Exception ex) {
                  resultLabel.setText("An error occurred while removing the Standard Room: " + ex.getMessage());
              }
          }
         
      }

