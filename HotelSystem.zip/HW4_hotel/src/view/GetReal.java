package view;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.Booking;
import model.Customer;
import model.Department;
import model.DepartmentManager;
import model.Employee;
import model.Hotel;
import model.StandardRoom;
import model.Suite;
import model.SuperiorRoom;
import model.VIPCustomer;

public class GetReal extends JInternalFrame implements ActionListener {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton bookingButton, customerButton, vipCustomerButton, employeeButton, departmentManagerButton,
            departmentButton, suiteButton, superiorRoomButton, standardRoomButton, closeButton;
    private JTextField bookingNumberTextField, customerIdTextField, vipCustomerIdTextField, employeeIdTextField,
            managerIdTextField, departmentIdTextField, roomNumberSuiteTextField, roomNumberSuperiorTextField,
            roomNumberStandardTextField;
    private JTextArea resultArea;

    public GetReal() {
        // Create JInternalFrame
        super();
        setSize(500, 700);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        getContentPane().setLayout(null);

        // Create Buttons
        bookingButton = new JButton("Get Real Booking");
        bookingButton.setBounds(50, 50, 200, 30);
        bookingButton.addActionListener(this);
        getContentPane().add(bookingButton);

        customerButton = new JButton("Get Real Customer");
        customerButton.setBounds(50, 100, 200, 30);
        customerButton.addActionListener(this);
        getContentPane().add(customerButton);

        vipCustomerButton = new JButton("Get Real VIP Customer");
        vipCustomerButton.setBounds(50, 150, 200, 30);
        vipCustomerButton.addActionListener(this);
        getContentPane().add(vipCustomerButton);

        employeeButton = new JButton("Get Real Employee");
        employeeButton.setBounds(50, 200, 200, 30);
        employeeButton.addActionListener(this);
        getContentPane().add(employeeButton);

        departmentManagerButton = new JButton("Get Real Department Manager");
        departmentManagerButton.setBounds(50, 250, 200, 30);
        departmentManagerButton.addActionListener(this);
        getContentPane().add(departmentManagerButton);

        departmentButton = new JButton("Get Real Department");
        departmentButton.setBounds(50, 300, 200, 30);
        departmentButton.addActionListener(this);
        getContentPane().add(departmentButton);

        suiteButton = new JButton("Get Real Suite");
        suiteButton.setBounds(50, 350, 200, 30);
        suiteButton.addActionListener(this);
        getContentPane().add(suiteButton);

        superiorRoomButton = new JButton("Get Real Superior Room");
        superiorRoomButton.setBounds(50, 400, 200, 30);
        superiorRoomButton.addActionListener(this);
        getContentPane().add(superiorRoomButton);

        standardRoomButton = new JButton("Get Real Standard Room");
        standardRoomButton.setBounds(50, 450, 200, 30);
        standardRoomButton.addActionListener(this);
        getContentPane().add(standardRoomButton);

        // Create Text Fields
        bookingNumberTextField = new JTextField();
        bookingNumberTextField.setBounds(260, 50, 200, 30);
        getContentPane().add(bookingNumberTextField);

        customerIdTextField = new JTextField();
        customerIdTextField.setBounds(260, 100, 200, 30);
        getContentPane().add(customerIdTextField);

        vipCustomerIdTextField = new JTextField();
        vipCustomerIdTextField.setBounds(260, 150, 200, 30);
        getContentPane().add(vipCustomerIdTextField);

        employeeIdTextField = new JTextField();
        employeeIdTextField.setBounds(260, 200, 200, 30);
        getContentPane().add(employeeIdTextField);

        managerIdTextField = new JTextField();
        managerIdTextField.setBounds(260, 250, 200, 30);
        getContentPane().add(managerIdTextField);

        departmentIdTextField = new JTextField();
        departmentIdTextField.setBounds(260, 300, 200, 30);
        getContentPane().add(departmentIdTextField);

        roomNumberSuiteTextField = new JTextField();
        roomNumberSuiteTextField.setBounds(260, 350, 200, 30);
        getContentPane().add(roomNumberSuiteTextField);

        roomNumberSuperiorTextField = new JTextField();
        roomNumberSuperiorTextField.setBounds(260, 400, 200, 30);
        getContentPane().add(roomNumberSuperiorTextField);

        roomNumberStandardTextField = new JTextField();
        roomNumberStandardTextField.setBounds(260, 450, 200, 30);
        getContentPane().add(roomNumberStandardTextField);

        // Create Text Area
        resultArea = new JTextArea();
        resultArea.setBounds(10, 496, 450, 63);
        resultArea.setEditable(false);
        getContentPane().add(resultArea);

        /*closeButton = new JButton("Close");
        closeButton.setBounds(50, 150, 200, 30);
        closeButton.addActionListener(this);
        getContentPane().add(closeButton);*/

        closeButton = new JButton("Close");
        closeButton.setBounds(150, 600, 200, 30);
        closeButton.addActionListener(this);
        getContentPane().add(closeButton);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bookingButton) {
            getRealBookingGui();
        } else if (e.getSource() == customerButton) {
            getRealCustomerGui();
        } else if (e.getSource() == vipCustomerButton) {
            getRealVIPCustomerGui();
        } else if (e.getSource() == employeeButton) {
            getRealEmployeeGui();
        } else if (e.getSource() == departmentManagerButton) {
            getRealDepartmentManagerGui();
        } else if (e.getSource() == departmentButton) {
            getRealDepartmentGui();
        } else if (e.getSource() == suiteButton) {
            getRealSuiteGui();
        } else if (e.getSource() == superiorRoomButton) {
            getRealSuperiorRoomGui();
        } else if (e.getSource() == standardRoomButton) {
            getRealStandardRoomGui();
        } else if (e.getSource() == closeButton) {
        	setVisible(false);
        }
    }

    // Add the existing methods you have provided above here

    /*public static void main(String[] args) {
        new GetReal();
    }*/

    private void getRealBookingGui() {
        try {
            String bookingNumber = bookingNumberTextField.getText();
            Booking booking = Hotel.getInstance().getRealBooking(bookingNumber);
            if (booking != null) {
                resultArea.setText("Booking Details:\n" + booking.toString());
            } else {
                JOptionPane.showMessageDialog(null, "Invalid Booking Number.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid booking number.");
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "Booking number cannot be null. Please enter a valid booking number.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while retrieving the Booking: " + ex.getMessage());
        }
    }

    // Similar changes for other methods

    private void getRealCustomerGui() {
        try {
            String customerId = customerIdTextField.getText();
            Customer customer = Hotel.getInstance().getRealCustomer(customerId);
            if (customer != null) {
                resultArea.setText("Customer Details:\n" + customer.toString());
            } else {
                JOptionPane.showMessageDialog(null, "Invalid Customer ID.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid Customer ID.");
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "Customer ID cannot be null. Please enter a valid Customer ID.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while retrieving the Customer: " + ex.getMessage());
        }
    }

    // GUI for Get Real VIP Customer
    private void getRealVIPCustomerGui() {
        try {
            String customerId = vipCustomerIdTextField.getText();
            VIPCustomer vipCustomer = Hotel.getInstance().getRealVIPCustomer(customerId);
            if (vipCustomer != null) {
                resultArea.setText("VIP Customer Details:\n" + vipCustomer.toString());
            } else {
                JOptionPane.showMessageDialog(null, "Invalid VIP Customer ID.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid VIP Customer ID.");
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "VIP Customer ID cannot be null. Please enter a valid VIP Customer ID.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while retrieving the VIP Customer: " + ex.getMessage());
        }
    }

    // GUI for Get Real Employee
    private void getRealEmployeeGui() {
        try {
            String employeeId = employeeIdTextField.getText();
            Employee employee = Hotel.getInstance().getRealEmployee(employeeId);
            if (employee != null) {
                resultArea.setText("Employee Details:\n" + employee.toString());
            } else {
                JOptionPane.showMessageDialog(null, "Invalid Employee ID.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid Employee ID.");
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "Employee ID cannot be null. Please enter a valid Employee ID.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while retrieving the Employee: " + ex.getMessage());
        }
    }

    // GUI for Get Real Department Manager
    private void getRealDepartmentManagerGui() {
        try {
            String managerId = managerIdTextField.getText();
            DepartmentManager manager = Hotel.getInstance().getRealDepartmentManager(managerId);
            if (manager != null) {
                resultArea.setText("Department Manager Details:\n" + manager.toString());
            } else {
                JOptionPane.showMessageDialog(null, "Invalid Department Manager ID.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid Department Manager ID.");
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "Department Manager ID cannot be null. Please enter a valid Department Manager ID.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while retrieving the Department Manager: " + ex.getMessage());
        }
    }

    // GUI for Get Real Department
    private void getRealDepartmentGui() {
        try {
            String departmentId = departmentIdTextField.getText();
            Department department = Hotel.getInstance().getRealDepartment(departmentId);
            if (department != null) {
                resultArea.setText("Department Details:\n" + department.toString());
            } else {
                JOptionPane.showMessageDialog(null, "Invalid Department ID.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid Department ID.");
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "Department ID cannot be null. Please enter a valid Department ID.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while retrieving the Department: " + ex.getMessage());
        }
    }

    // GUI for Get Real Suite
    private void getRealSuiteGui() {
        try {
            String roomNumber = roomNumberSuiteTextField.getText();
            Suite room = Hotel.getInstance().getRealSuite(roomNumber);
            if (room != null) {
                resultArea.setText("Suite Details:\n" + room.toString());
            } else {
                JOptionPane.showMessageDialog(null, "Invalid room number or not a Suite.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid room number.");
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "Room number cannot be null. Please enter a valid room number.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while retrieving the Suite: " + ex.getMessage());
        }
    }

    // GUI for Get Real Superior Room
    private void getRealSuperiorRoomGui() {
        try {
            String roomNumber = roomNumberSuperiorTextField.getText();
            SuperiorRoom room = Hotel.getInstance().getRealSuperiorRoom(roomNumber);
            if (room != null) {
                resultArea.setText("Superior Room Details:\n" + room.toString());
            } else {
                JOptionPane.showMessageDialog(null, "Invalid room number or not a Superior Room.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid room number.");
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "Room number cannot be null. Please enter a valid room number.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while retrieving the Superior Room: " + ex.getMessage());
        }
    }

    // GUI for Get Real Standard Room
    private void getRealStandardRoomGui() {
        try {
            String roomNumber = roomNumberStandardTextField.getText();
            StandardRoom room = Hotel.getInstance().getRealStandardRoom(roomNumber);
            if (room != null) {
                resultArea.setText("Standard Room Details:\n" + room.toString());
            } else {
                JOptionPane.showMessageDialog(null, "Invalid room number or not a Standard Room.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid room number.");
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(null, "Room number cannot be null. Please enter a valid room number.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "An error occurred while retrieving the Standard Room: " + ex.getMessage());
        }
    }
}
