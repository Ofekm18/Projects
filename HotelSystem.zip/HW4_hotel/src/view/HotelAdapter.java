package view;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import model.Hotel;

public class HotelAdapter {

    private static final String FILE_PATH = "hotel.ser";

    public static void saveData(Hotel hotel) {
        File file = new File(FILE_PATH);
        
        if (!file.exists()) {
            try {
                if (!file.createNewFile()) {
                    System.out.println("Failed to create the file.");
                    return;
                }
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
                return;
            }
        }

        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            out.writeObject(hotel);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Hotel loadData() {
        File file = new File(FILE_PATH);

        // Check if the file exists
        if (!file.exists()) {
            return Hotel.getInstance();
        }

        Hotel hotel = null;
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(FILE_PATH))) {
            hotel = (Hotel) in.readObject();
            if (hotel != null) {
                hotel.setInstance(hotel);
            }
            return hotel;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;  // return null if there's an exception
        }
    }

}
