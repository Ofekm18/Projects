package view;

import javax.swing.*;
import model.Hotel;
import model.MaxPopulationCapacityException;
import model.Room;
import model.StandardRoom;
import model.Suite;
import model.SuperiorRoom;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddRoom extends JInternalFrame {
    private static final long serialVersionUID = 1L;
    private Hotel h;
    private JPanel selectionPanel;
    private JPanel detailsPanel;
    private JComboBox<String> roomTypeBox;
    private JButton proceedButton;
    private JButton addButton;
    private JButton cancelButton;
    // Common room fields
    private JTextField dailyPriceField, avgDailyCostField, roomGradeField, maxPopulationCapacityField, sizeField, floorField;
    private JCheckBox hasViewField, hasJacuzziField, isBookedField;
    // Suite Room Field
    private JTextField balconySizeField;

    public AddRoom(Hotel hotel) {
        this.h = hotel;
        setTitle("Add Room");
        setSize(600, 400);

        selectionPanel = new JPanel();
        selectionPanel.setLayout(new FlowLayout());

        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(new String[]{"Standard Room", "Superior Room", "Suite"});
        roomTypeBox = new JComboBox<>();
        roomTypeBox.setModel(model);

        proceedButton = new JButton("Proceed");
        addButton = new JButton("Add");
        cancelButton = new JButton("Cancel");

        selectionPanel.add(new JLabel("Select Room Type:"));
        selectionPanel.add(roomTypeBox);
        selectionPanel.add(proceedButton);

        detailsPanel = new JPanel();
        detailsPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon backgroundImage = new ImageIcon(getClass().getResource("/utils/HotelRoom.jpg"));
                Image img = backgroundImage.getImage();
                g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
            }
        };

        // Initialize the detailsPanel
        detailsPanel.setLayout(new GridLayout(0, 2));
detailsPanel.setLayout(new GridLayout(0, 2));

        proceedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createRoomFields((String) roomTypeBox.getSelectedItem());
            }
        });

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String roomType = (String) roomTypeBox.getSelectedItem();

                String dailyPriceText = dailyPriceField.getText();
                String floorText = floorField.getText();
                String avgDailyCostText = avgDailyCostField.getText();
                String roomGradeText = roomGradeField.getText();
                String maxPopulationCapacityText = maxPopulationCapacityField.getText();
                String sizeText = sizeField.getText();
                String hasViewText = hasViewField.isSelected() ? "true" : "false";

                if (!isValidDoubleInput(dailyPriceText, "Daily Price") ||
                    !isValidIntInput(floorText, "Floor") ||
                    !isValidDoubleInput(avgDailyCostText, "Average Daily Cost") ||
                    !isValidDoubleInput(roomGradeText, "Room Grade") ||
                    !isValidIntInput(maxPopulationCapacityText, "Max Population Capacity") ||
                    !isValidIntInput(sizeText, "Size") ||
                    !isValidBooleanInput(hasViewText, "Has View")) {
                    return;
                }

                Double dailyPrice = Double.parseDouble(dailyPriceText);
                int floor = Integer.parseInt(floorText);
                Double avgDailyCost = Double.parseDouble(avgDailyCostText);
                Double roomGrade = Double.parseDouble(roomGradeText);
                int maxPopulationCapacity = Integer.parseInt(maxPopulationCapacityText);
                if (maxPopulationCapacity <= 0) {
                    showErrorDialog("Bad value for Capacity.");
                	return;
                }
                int size = Integer.parseInt(sizeText);
                boolean hasView = Boolean.parseBoolean(hasViewText);

                Room room = null;

                switch (roomType) {
                    case "Standard Room":
                        if ((maxPopulationCapacity < 1) || (maxPopulationCapacity > 2)) {
                            showErrorDialog("Capacity for Standard Room can be 1 or 2.");
                        	return;
                        }
                        room = new StandardRoom(dailyPrice, floor, avgDailyCost, roomGrade, maxPopulationCapacity, size, hasView);
    					try {
    						h.addStandardRoom((StandardRoom) room);
    	                    JOptionPane.showMessageDialog(null, "Room added successfully");
    	                    setVisible(false);
    					} catch (MaxPopulationCapacityException e1) {
    	                    showErrorDialog(e1.getMessage());
    					}
                        break;
                    case "Superior Room":
                        if (hasJacuzziField == null) {
                            showErrorDialog("Please select the Superior Room type first.");
                            return;
                        }
                        if ((maxPopulationCapacity < 3) || (maxPopulationCapacity > 5)) {
                            showErrorDialog("Capacity for Superior Room must be between 3 and 5.");
                        	return;
                        }
                        boolean hasJacuzzi = hasJacuzziField.isSelected();
                        room = new SuperiorRoom(dailyPrice, floor, avgDailyCost, roomGrade, maxPopulationCapacity, size, hasView, hasJacuzzi);
    					try {
    						h.addSuperiorRoom((SuperiorRoom) room);
    	                    JOptionPane.showMessageDialog(null, "Room added successfully");
    	                    setVisible(false);
    					} catch (MaxPopulationCapacityException e1) {
    	                    showErrorDialog(e1.getMessage());
    					}
                        break;
                    case "Suite":
                        if (hasJacuzziField == null) {
                            showErrorDialog("Please select the Suite type first.");
                            return;
                        }
                        if ((maxPopulationCapacity < 1) || (maxPopulationCapacity > 7)) {
                            showErrorDialog("Capacity for Suite must be between 1 and 7.");
                        	return;
                        }
                        boolean hasJacuzziForSuite = hasJacuzziField.isSelected();
                        String balconySizeText = balconySizeField.getText();
                        if (!isValidDoubleInput(balconySizeText, "Balcony Size")) {
                            return;
                        }
                        Double balconySize = Double.parseDouble(balconySizeText);
                        room = new Suite(dailyPrice, floor, avgDailyCost, roomGrade, maxPopulationCapacity, size, hasView, hasJacuzziForSuite, balconySize);
					try {
						h.addSuite((Suite) room);
	                    JOptionPane.showMessageDialog(null, "Room added successfully");
	                    setVisible(false);
					} catch (MaxPopulationCapacityException e1) {
	                    showErrorDialog(e1.getMessage());
					}
                        break;
                }

            }
        });

        cancelButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				detailsPanel.removeAll();
				
			}
		});
        setLayout(new BorderLayout());
        add(selectionPanel, BorderLayout.NORTH);
        add(detailsPanel, BorderLayout.CENTER);
    
    }

    private void createRoomFields(String roomType) {
        // Reset the details panel
        detailsPanel.removeAll();
        detailsPanel.setLayout(new GridLayout(0, 2));

        // Common room fields
        dailyPriceField = new JTextField();
        avgDailyCostField = new JTextField();
        roomGradeField = new JTextField();
        maxPopulationCapacityField = new JTextField();
        sizeField = new JTextField();
        floorField = new JTextField();
        isBookedField = new JCheckBox();
        hasViewField = new JCheckBox();

        // Add common fields to detailsPanel
        JLabel label = getStyledLabel("Daily Price:");
        detailsPanel.add(label);
        detailsPanel.add(dailyPriceField);
        label = getStyledLabel("Floor:");
        detailsPanel.add(label);
        detailsPanel.add(floorField);
        label = getStyledLabel("Average Daily Cost:");
        detailsPanel.add(label);
        detailsPanel.add(avgDailyCostField);
        label = getStyledLabel("Room Grade:");
        detailsPanel.add(label);
        detailsPanel.add(roomGradeField);
        label = getStyledLabel("Capacity:");
        detailsPanel.add(label);
        detailsPanel.add(maxPopulationCapacityField);
        label = getStyledLabel("Size:");
        detailsPanel.add(label);
        detailsPanel.add(sizeField);
        
        label = getStyledLabel("Has View (true/false):");
        detailsPanel.add(label);
        detailsPanel.add(hasViewField);

        switch (roomType) {
            case "Superior Room":
                // Superior room fields
                hasJacuzziField = new JCheckBox();
                detailsPanel.add(new JLabel("Has Jacuzzi (true/false):"));
                detailsPanel.add(hasJacuzziField);
                break;
            case "Suite":
                // Suite room fields
                hasJacuzziField = new JCheckBox();
                balconySizeField = new JTextField();
                detailsPanel.add(new JLabel("Has Jacuzzi (true/false):"));
                detailsPanel.add(hasJacuzziField);
                detailsPanel.add(new JLabel("Balcony Size:"));
                detailsPanel.add(balconySizeField);
                break;
        }

        // Add the "Add" button to the detailsPanel
        detailsPanel.add(addButton);
        // Add the "Cancel" button to the detailsPanel
        detailsPanel.add(cancelButton);

        // Refresh panel
        detailsPanel.revalidate();
        detailsPanel.repaint();
    }

    private JLabel getStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.RED);
        label.setFont(new Font("Arial", Font.BOLD, 30));
        return label;
    }
    private void showErrorDialog(String errorMessage) {
        JOptionPane.showMessageDialog(this, errorMessage, "Error", JOptionPane.ERROR_MESSAGE);
    }
 // check if valid
    private boolean isValidDoubleInput(String input, String fieldName) {
        try {
            Double.parseDouble(input);
            return true;
        } catch (NumberFormatException e) {
            showErrorDialog(fieldName + " must be a valid number.");
            return false;
        }
    }
 // check if valid
    private boolean isValidIntInput(String input, String fieldName) {
        try {
            Integer.parseInt(input);
            return true;
        } catch (NumberFormatException e) {
            showErrorDialog(fieldName + " must be a valid whole number.");
            return false;
        }
    }
// check if valid
    private boolean isValidBooleanInput(String input, String fieldName) {
        if ("true".equalsIgnoreCase(input) || "false".equalsIgnoreCase(input)) {
            return true;
        } else {
            showErrorDialog(fieldName + " must be true or false.");
            return false;
        }
    }

    
}
