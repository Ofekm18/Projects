package view;

import javax.swing.*;

import Exceptions.InvalidNumericStringException;
import model.Customer;
import model.Department;
import model.DepartmentManager;
import model.Employee;
import model.Hotel;
import model.PersonAlreadyExistException;
import utils.Area;
import utils.Gender;
import utils.Specialization;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class AddEmployeeType extends JInternalFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Hotel hotelData;
    private JComboBox<Area> areaComboBox;
    private JComboBox<Department> departmentComboBox;
	private JTextField fieldId;
	private JTextField fieldFirstName;
	private JTextField fieldLastName;
	private JTextField fieldPhoneNumber;
	private JTextField fieldYearOfBirth;
	private JTextField fieldStartOfWork;
	private JTextField fieldSalary;
	private JPasswordField fieldPassword;
	private JComboBox<Gender> customerGenderBox;

    public AddEmployeeType(Hotel hotelData) {
        super("Add Employee", false, true, false, true);
        this.hotelData = hotelData;
        setLayout(new BorderLayout());

        // Department Manager Panel
        JPanel departmentManagerPanel = createDepartmentManagerPanel();
        add(departmentManagerPanel, BorderLayout.SOUTH);

        // Employee Panel
        JPanel employeePanel = createEmployeePanel();
        add(employeePanel, BorderLayout.CENTER);

        pack();
    }

    private JPanel createDepartmentManagerPanel() {
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createTitledBorder("Add Department Manager"));

        panel.add(new JLabel("Bonus:"));
        JTextField bonusField = new JTextField(10);
        panel.add(bonusField);

        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(new ActionListener() {
        	@Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Double bonus = 0.0;
                    try {
                    	bonus = Double.valueOf(bonusField.getText());
                    } catch (Exception ex) {
                    	throw new InvalidNumericStringException(ex.getMessage());
                    }
                    Employee employee = getEmployee();
                    if (employee == null)
                    	return;
                    DepartmentManager departmentManager = new DepartmentManager(employee.getId(), employee.getFirstName(), employee.getLastName(), employee.getPhoneNumber(), employee.getArea(), employee.getGender(),
                    		employee.getYearOfBirth(),employee.getStartOfWork(),employee.getSalary(), employee.getDepartment(), bonus, employee.getPassword());
                            hotelData.addEmployee(departmentManager);
                    JOptionPane.showMessageDialog(null, "Department Manager added successfully.");
                    bonusField.setText("");
                    setVisible(false);
                } catch (InvalidNumericStringException ex) {
                    JOptionPane.showMessageDialog(null, "Invalid input: " + ex.getMessage());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error adding department manager: " + ex.getMessage());
                }
            }
        });
        panel.add(submitButton);

        return panel;
    }

    Employee getEmployee() throws InvalidNumericStringException {
        String id = fieldId.getText();
        try {
        	Integer intID = Integer.valueOf(id);
        } catch (Exception e) {
        	throw new InvalidNumericStringException(e.getMessage());
        }
        if (hotelData.getRealEmployee(id) != null) {
            JOptionPane.showMessageDialog(this, "Employee with same ID already exist!!!", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
        String firstName = fieldFirstName.getText();
        String lastName = fieldLastName.getText();
        String phoneNumber = fieldPhoneNumber.getText();
        try {
        	Integer.parseInt(fieldPhoneNumber.getText());
        } catch(NumberFormatException nfe) {
        	throw new InvalidNumericStringException(nfe.getMessage());
        }
        Area area = (Area) areaComboBox.getSelectedItem(); //  Area is an enum
        Gender gender = (Gender) customerGenderBox.getSelectedItem(); //  Gender is an enum
        int yearOfBirth = Integer.parseInt(fieldYearOfBirth.getText());
        int startOfWork = Integer.parseInt(fieldStartOfWork.getText());
        double salary = Double.parseDouble(fieldSalary.getText());
     // Check if startOfWork year is smaller than yearOfBirth
        if (startOfWork <= yearOfBirth) {
            JOptionPane.showMessageDialog(this, "Start of work year cannot be earlier than the birth year!", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
        Department department = (Department) departmentComboBox.getSelectedItem();
        if (department == null) {
            JOptionPane.showMessageDialog(null, "No department selected", "Error", JOptionPane.ERROR_MESSAGE);
        	return null;
        }

        // Create employee and add it to the hotel
        String password = new String(fieldPassword.getPassword());
        Employee employee = new Employee(id, firstName, lastName, phoneNumber, area, gender, yearOfBirth, startOfWork, salary, department, password);
        return employee;
    }


    private JPanel createEmployeePanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(12, 2));

        JLabel labelId = new JLabel("ID (user name):");
        fieldId = new JTextField();

        JLabel labelFirstName = new JLabel("First Name:");
        fieldFirstName = new JTextField();

        JLabel labelLastName = new JLabel("Last Name:");
        fieldLastName = new JTextField();

        JLabel labelPhoneNumber = new JLabel("Phone Number:");
        fieldPhoneNumber = new JTextField();

        JLabel labelArea = new JLabel("Area:");
        areaComboBox = new JComboBox<Area>(Area.values());

        JLabel labelGender = new JLabel("Gender:");
        customerGenderBox = new JComboBox(Gender.values());

        JLabel labelYearOfBirth = new JLabel("Year Of Birth:");
        fieldYearOfBirth = new JTextField();

        JLabel labelStartOfWork = new JLabel("Start Of Work:");
        fieldStartOfWork = new JTextField();

        JLabel labelSalary = new JLabel("Salary:");
        fieldSalary = new JTextField();

        JLabel labelDepartment = new JLabel("Department:");
        departmentComboBox = new JComboBox<Department>();
        rebuild();

        JLabel labelPassword = new JLabel("Password:");
        fieldPassword = new JPasswordField();

        JButton buttonSubmit = new JButton("Submit");
        buttonSubmit.addActionListener(e -> {
            try {
                Employee employee = getEmployee();
                if (employee == null)
                	return;
                hotelData.addEmployee(employee);
                JOptionPane.showMessageDialog(null, "Employee added successfully");
                // Clear fields
                fieldId.setText("");
                fieldFirstName.setText("");
                fieldLastName.setText("");
                fieldPhoneNumber.setText("");
                fieldYearOfBirth.setText("");
                fieldStartOfWork.setText("");
                fieldSalary.setText("");
                fieldPassword.setText("");
                setVisible(false);
            } catch (PersonAlreadyExistException ex) {
                JOptionPane.showMessageDialog(null, "Error adding employee: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException ex) {
                // Show error message to the user
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            } catch (InvalidNumericStringException ex) {
                JOptionPane.showMessageDialog(null, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }

        });
        JButton cancelSubmit = new JButton("Cancel");
        cancelSubmit.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
                setVisible(false);
			}
		});

        panel.add(labelId);
        panel.add(fieldId);
        panel.add(labelFirstName);
        panel.add(fieldFirstName);
        panel.add(labelLastName);
        panel.add(fieldLastName);
        panel.add(labelPhoneNumber);
        panel.add(fieldPhoneNumber);
        panel.add(labelArea);
        panel.add(areaComboBox);
        panel.add(labelGender);
        panel.add(customerGenderBox);
        panel.add(labelYearOfBirth);
        panel.add(fieldYearOfBirth);
        panel.add(labelStartOfWork);
        panel.add(fieldStartOfWork);
        panel.add(labelSalary);
        panel.add(fieldSalary);
        panel.add(labelDepartment);
        panel.add(departmentComboBox);
        panel.add(labelPassword);
        panel.add(fieldPassword);
        panel.add(buttonSubmit);
        panel.add(cancelSubmit);

        return panel;
    }

	public void rebuild() {
		departmentComboBox.removeAllItems();
        HashMap<String, Department> hotelDepertments = hotelData.getAllDepartments();
        Iterator<Map.Entry<String, Department> > new_Iterator = hotelDepertments.entrySet().iterator();
        while (new_Iterator.hasNext()) {
        	Map.Entry<String, Department> entry = new_Iterator.next();
        	departmentComboBox.addItem(entry.getValue());
        }
	}
}
