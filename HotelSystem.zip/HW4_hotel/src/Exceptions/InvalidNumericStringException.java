package Exceptions;

public class InvalidNumericStringException extends Exception {
    private static final long serialVersionUID = 1L;

    public InvalidNumericStringException(String message) {
        super(message);
    }
}