import java.util.*;

class Cell {
    int x, y;
    int cost;        // g
    int heuristic;   // h
    int totalCost;   // f = g + h
    boolean isWall;
    private char name;
    Cell parent;     // To trace the path

    Cell(int x, int y) {
        this.x = x;
        this.y = y;
        this.cost = Integer.MAX_VALUE;  // Initialize with a high cost
        this.heuristic = 0;
        this.totalCost = Integer.MAX_VALUE;  // Initialize with a high total cost
        this.isWall = false;
        this.name = ' ';  // Initialize with a space or any default value
        this.parent = null;
    }

    public char getName() {
        return name;
    }

    public void setName(char name) {
        this.name = name;
    }

    public int calculateTotalCost() {
        this.totalCost = this.cost + this.heuristic;
        return totalCost;
    }
     

    void calculateHeuristic(Cell goal) {
        this.heuristic = Math.abs(this.x - goal.x) + Math.abs(this.y - goal.y); // Manhattan distance
    }
}
