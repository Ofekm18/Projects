import java.util.*;
public class Maze {

    public static void main(String[] args) {
    	int n = 0;
    
    	Scanner scanner = new Scanner(System.in);
    	
    		System.out.println("Please enter a positive number bigger than 10 for the size of the maze:");
    		
    		 while (n <= 10) {
    	            try {
    	                String input = scanner.nextLine(); // Read input as string
    	                if (input.chars().anyMatch(Character::isWhitespace)) {
    	                    throw new InputMismatchException("Input contains spaces");
    	                }
    	                n = Integer.parseInt(input);
    	                if (n <= 10) {
    	                    System.out.println("The number must be bigger than 10. Try again:");
    	                }
    	            } catch (InputMismatchException | NumberFormatException e) {
    	                System.out.println("Invalid input. Please enter a valid number without spaces:");
    	                
    	            }
    	        }

    	        double wallPercentage = -1;
    	        System.out.println("Please enter a wall percentage between 0 and 0.3:");

    	        while (wallPercentage < 0 || wallPercentage > 0.3) {
    	            try {
    	                String input = scanner.nextLine(); // Read input as string
    	                if (input.chars().anyMatch(Character::isWhitespace)) {
    	                    throw new InputMismatchException("Input contains spaces");
    	                }
    	                wallPercentage = Double.parseDouble(input);
    	                if (wallPercentage < 0 || wallPercentage > 0.3) {
    	                    System.out.println("The wall percentage must be between 0 and 0.3. Try again:");
    	                }
    	            } catch (InputMismatchException | NumberFormatException e) {
    	                System.out.println("Invalid input. Please enter a valid percentage without spaces:");
    	               
    	            }
    	        }
        // Generate the maze and find the solution
        generateMaze(n, wallPercentage);
    }

    public static void generateMaze(int n, double wallPercentage) {
        // Seed the Random object with the current time to ensure different results each run
        Random random = new Random(System.currentTimeMillis());

        Cell[][] maze = new Cell[n][n];
        boolean pathFound = false;

        while (!pathFound) {
            // Initialize the maze with Cell objects
            initializeMaze(maze, n);

            // Generate random walls
            generateFences(maze, n, wallPercentage, random);

            maze[0][0].isWall = false;  // Ensure start is not a wall
            maze[0][0].setName('S');
            maze[n-1][n-1].isWall = false; // Ensure finish is not a wall
            maze[n-1][n-1].setName('F');

            // Ensure `S` and `F` are not surrounded by walls
            ensureNotSurrounded(maze, n);

            // Check for path using A* algorithm
            pathFound = aStar(maze, n);

            if (!pathFound) {
                System.out.println("No solution found, regenerating maze...");
            }
        }

        // Output the final maze with solution path
        printMaze(maze, n, "Maze with Solution Path:");
    }

    private static void initializeMaze(Cell[][] maze, int n) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                maze[i][j] = new Cell(i, j);
            }
        }
    }

    private static void generateFences(Cell[][] maze, int n, double wallPercentage, Random random) {
        // Set the perimeter walls
        for (int i = 0; i < n; i++) {
            maze[i][0].isWall = true;
            maze[i][n-1].isWall = true;
            maze[0][i].isWall = true;
            maze[n-1][i].isWall = true;
        }

        // Generate internal walls
        int wallCount = (int) (n * n * wallPercentage);
        int placedWalls = 0;

        while (placedWalls < wallCount) {
            int x = random.nextInt(n);
            int y = random.nextInt(n);
            int direction = random.nextBoolean() ? 0 : 5;

            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 5; j++) {
                    int newX = x + (direction == 0 ? i : 0);
                    int newY = y + (direction == 0 ? 0 : j);
                    if (isValid(newX, newY, n) && !maze[newX][newY].isWall && maze[newX][newY].getName() == ' ' && !(newX == 0 && newY == 0) && !(newX == n-1 && newY == n-1)) {
                        maze[newX][newY].isWall = true;
                        placedWalls++;
                        if (placedWalls >= wallCount) {
                            break;
                        }
                    }
                }
                if (placedWalls >= wallCount) {
                    break;
                }
            }
        }
    }

    


    private static void ensureNotSurrounded(Cell[][] maze, int n) {
        ensureCellNotSurrounded(maze, 0, 0, n); // Ensure start cell `S` is not surrounded
        ensureCellNotSurrounded(maze, n-1, n-1, n); // Ensure finish cell `F` is not surrounded
    }

    private static void ensureCellNotSurrounded(Cell[][] maze, int x, int y, int n) {
    	 int[] dx = {-1, 1, 0, 0};
         int[] dy = {0, 0, -1, 1};
        for (int i = 0; i < 4; i++) {
            int newX = x + dx[i];
            int newY = y + dy[i];
            if (isValid(newX, newY, n) && maze[newX][newY].isWall) {
                maze[newX][newY].isWall = false;
            }
        }
    }

    private static boolean isValid(int x, int y, int n) {
        return x >= 0 && y >= 0 && x < n && y < n;
    }

    private static boolean aStar(Cell[][] maze, int n) {
        PriorityQueue<Cell> openList = new PriorityQueue<>(Comparator.comparingInt(c -> c.totalCost));
        Set<Cell> closedList = new HashSet<>();
        Cell start = maze[0][0];
        Cell goal = maze[n-1][n-1];

        start.cost = 0;
        start.calculateHeuristic(goal);
        start.calculateTotalCost();
        openList.add(start);

        while (!openList.isEmpty()) {
            Cell current = openList.poll();
            closedList.add(current);

            if (current.getName() == 'F') {
                tracePath(goal);
                return true;
            }

            for (Cell neighbor : getNeighbors(current, maze, n)) {
                if (!neighbor.isWall && !closedList.contains(neighbor)) {
                    int tentativeCost = current.cost + 1; // Assuming uniform cost of 1 for each step
                    if (tentativeCost < neighbor.cost) {
                        neighbor.cost = tentativeCost;
                        neighbor.calculateHeuristic(goal);
                        neighbor.calculateTotalCost();
                        neighbor.parent = current;
                        if (!openList.contains(neighbor)) {
                            openList.add(neighbor);
                        }
                    }
                }
            }
        }
        return false;
    }

    private static List<Cell> getNeighbors(Cell cell, Cell[][] maze, int n) {
        int x = cell.x;
        int y = cell.y;
        List<Cell> neighbors = new ArrayList<>();

        if (x + 1 < n) neighbors.add(maze[x + 1][y]);
        if (x - 1 >= 0) neighbors.add(maze[x - 1][y]);
        if (y + 1 < n) neighbors.add(maze[x][y + 1]);
        if (y - 1 >= 0) neighbors.add(maze[x][y - 1]);

        return neighbors;
    }

    private static void tracePath(Cell goal) {
        Cell current = goal;
        int pathCost = 0;
        while (current != null) {
            if (current.getName() != 'S' && current.getName() != 'F') {
                current.setName('*');
            }
            pathCost += current.cost;
            current = current.parent;
        }
        System.out.println("Path cost: " + pathCost);
    }

    private static void printMaze(Cell[][] maze, int n, String message) {
        System.out.println(message);
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (maze[i][j].isWall) {
                    System.out.print("# ");
                } else {
                    System.out.print(maze[i][j].getName() + " ");
                }
            }
            System.out.println();
        }
    }
}